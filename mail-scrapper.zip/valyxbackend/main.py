import imaplib
import email
import pdfplumber
import os
import pandas as pd

# Gmail login details
GMAIL_USER = "yourmail@gmail.com"
GMAIL_PASSWORD = "your app password"

# Search criteria
EMAIL_SUBJECT = "subject you want"#eg:bank statements
PDF_KEYWORDS = ["invoice", "purchase order", "tax form","transactions"]

# Directory to save extracted data
SAVE_DIR = "extracted_data"

# Spreadsheet/CSV file path
SPREADSHEET_FILE = "extracted_data.xlsx"  # Change the format as needed (e.g., .csv)

def get_emails():
    mail = imaplib.IMAP4_SSL("imap.gmail.com")
    mail.login(GMAIL_USER, GMAIL_PASSWORD)
    mail.select("inbox")

    result, data = mail.search(None, f'SUBJECT "{EMAIL_SUBJECT}"')
    email_ids = data[0].split()
    
    emails = []
    for email_id in email_ids:
        result, msg_data = mail.fetch(email_id, "(RFC822)")
        msg = email.message_from_bytes(msg_data[0][1])
        emails.append(msg)
    
    return emails

def extract_data_from_pdf(pdf_path):
    with pdfplumber.open(pdf_path) as pdf:
        text = ""
        for page in pdf.pages:
            text += page.extract_text()
    return text

def convert_extracted_data_to_spreadsheet(directory, spreadsheet_file):
    data = []

    for filename in os.listdir(directory):
        if filename.endswith(".pdf"):
            pdf_path = os.path.join(directory, filename)
            extracted_text = extract_data_from_pdf(pdf_path)
            data.append({"Filename": filename, "Extracted Data": extracted_text})

    df = pd.DataFrame(data)
    df.to_excel(spreadsheet_file, index=False)

def main():
    emails = get_emails()

    if not os.path.exists(SAVE_DIR):
        os.makedirs(SAVE_DIR)

    for email_msg in emails:
        for part in email_msg.walk():
            if part.get_content_maintype() == "application" and part.get("Content-Disposition") is not None:
                filename = part.get_filename()
                pdf_path = os.path.join(SAVE_DIR, filename)
                with open(pdf_path, "wb") as f:
                    f.write(part.get_payload(decode=True))

    convert_extracted_data_to_spreadsheet(SAVE_DIR, SPREADSHEET_FILE)

if __name__ == "__main__":
    main()
